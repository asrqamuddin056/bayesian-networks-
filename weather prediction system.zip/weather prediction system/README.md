# Weather Prediction System (Naive Bayes)

A simple, client-side weather prediction demo using Naive Bayes with:
- Gaussian likelihoods for numeric features
- Laplace-smoothed likelihoods for categorical features
- Synthetic data generation engineered for separability
- 5-fold cross-validation to report estimated accuracy

## Files
- `index.html` – UI with inputs and results
- `styles.css` – Minimal styling
- `app.js` – Naive Bayes, synthetic dataset, cross-validation, handlers

## How to run
1. Open `index.html` by double-clicking it, or right-click → Open With → your browser.
2. Wait for "Model trained" in the "Model Status" card.
3. Enter current conditions and click "Predict".
4. Click "Regenerate Data & Retrain" to create a new synthetic dataset and retrain.

No server is required; this is fully static and runs in the browser.

## Notes on accuracy
- The reported accuracy (k=5 CV) is on the synthetic dataset, crafted to be reasonably separable. You should typically see ~90–96%.
- Real-world accuracy depends on the quality and representativeness of your data. Replace the synthetic generator with your dataset to evaluate realistic performance.

## Customization
- Features used: `temperature`, `humidity`, `pressure`, `wind`, `cloud`, and categorical `season`.
- To adjust dataset size or distributions, see generator functions in `app.js`:
  - `generateData(n)` to change dataset size (default 1200).
  - Edit `genRow()` and helpers like `tempBySeason()` to tweak class-conditional distributions.
- To add/remove features:
  - Update form fields in `index.html`.
  - Update model config in `app.js` constructor call (`numeric`, `categorical`).
  - Ensure your generator or data loader provides those fields.

## Using your own data
You can replace the synthetic data with your data:
1. Create an array of rows like:
```js
[
  { temperature: 24.5, humidity: 72, pressure: 1008.2, wind: 3.2, cloud: 85, season: 'Summer', label: 'Yes' },
  { temperature: 31.1, humidity: 48, pressure: 1017.5, wind: 2.8, cloud: 20, season: 'Summer', label: 'No' }
]
```
2. Set `state.dataset = yourArray;` and call `nb.fit(yourArray)` in place of `generateData()` inside `trainAndReport()`.
3. Keep labels as `'Yes'` or `'No'` for rain.

## License
MIT
