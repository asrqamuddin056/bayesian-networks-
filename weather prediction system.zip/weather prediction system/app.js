(function(){
  const state = {
    dataset: [],
    model: null
  };

  function mean(arr){ return arr.reduce((a,b)=>a+b,0)/arr.length; }
  function std(arr){ const m=mean(arr); const v=arr.reduce((s,x)=>s+(x-m)*(x-m),0)/Math.max(arr.length-1,1); return Math.sqrt(v||1e-6); }
  function gaussianLogPdf(x, m, s){ const var2 = s*s || 1e-6; return -0.5*Math.log(2*Math.PI*var2) - ((x-m)*(x-m))/(2*var2); }

  class NaiveBayes {
    constructor(opts){
      this.numeric = opts.numeric;
      this.categorical = opts.categorical;
      this.classes = opts.classes;
      this.stats = null;
      this.priors = null;
      this.catMaps = null;
    }

    fit(rows){
      const byClass = new Map();
      for(const r of rows){
        if(!byClass.has(r.label)) byClass.set(r.label, []);
        byClass.get(r.label).push(r);
      }
      const total = rows.length;
      this.priors = {};
      for(const c of this.classes){
        const n = (byClass.get(c)||[]).length;
        this.priors[c] = Math.log((n + 1) / (total + this.classes.length));
      }

      this.stats = {};
      for(const c of this.classes){
        const rowsC = byClass.get(c)||[];
        this.stats[c] = {};
        for(const key of this.numeric){
          const arr = rowsC.map(r=>r[key]);
          const m = arr.length? mean(arr):0;
          const s = arr.length? std(arr):1;
          this.stats[c][key] = {m, s: s || 1e-3};
        }
      }

      this.catMaps = {};
      for(const c of this.classes){
        const rowsC = byClass.get(c)||[];
        this.catMaps[c] = {};
        for(const key of this.categorical){
          const counts = new Map();
          for(const r of rows){
            const v = r[key];
            counts.set(v, 0);
          }
          for(const r of rowsC){
            const v = r[key];
            counts.set(v, (counts.get(v)||0)+1);
          }
          const K = counts.size || 1;
          const N = rowsC.length;
          const logp = new Map();
          for(const [val, cnt] of counts.entries()){
            logp.set(val, Math.log((cnt + 1) / (N + K)));
          }
          this.catMaps[c][key] = logp;
        }
      }
    }

    predictProba(row){
      const scores = {};
      for(const c of this.classes){
        let logp = this.priors[c];
        for(const key of this.numeric){
          const {m, s} = this.stats[c][key];
          logp += gaussianLogPdf(row[key], m, s);
        }
        for(const key of this.categorical){
          const m = this.catMaps[c][key];
          logp += (m.get(row[key]) ?? Math.log(1e-9));
        }
        scores[c] = logp;
      }
      const maxLog = Math.max(...Object.values(scores));
      const exps = Object.fromEntries(Object.entries(scores).map(([k,v])=>[k, Math.exp(v - maxLog)]));
      const Z = Object.values(exps).reduce((a,b)=>a+b,0);
      const probs = Object.fromEntries(Object.entries(exps).map(([k,v])=>[k, v/Z]));
      return probs;
    }

    predict(row){
      const p = this.predictProba(row);
      const entries = Object.entries(p).sort((a,b)=>b[1]-a[1]);
      return {label: entries[0][0], probs: p};
    }
  }

  const seasons = ['Summer','Autumn','Winter','Spring'];

  function clamp(x,min,max){ return Math.max(min, Math.min(max, x)); }
  function randn(){
    let u=0,v=0; while(u===0) u=Math.random(); while(v===0) v=Math.random();
    return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);
  }
  function rnorm(mu, sigma){ return mu + sigma*randn(); }
  function runif(a,b){ return a + Math.random()*(b-a); }
  function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }

  function tempBySeason(season, rain){
    switch(season){
      case 'Summer': return rain? rnorm(26,3): rnorm(32,3.5);
      case 'Winter': return rain? rnorm(8,3): rnorm(4,3);
      case 'Spring': return rain? rnorm(18,3): rnorm(22,3);
      case 'Autumn': return rain? rnorm(16,3): rnorm(20,3);
      default: return rnorm(20,5);
    }
  }

  function genRow(){
    const label = Math.random()<0.45? 'Yes':'No';
    const season = pick(seasons);

    let humidity = label==='Yes'? rnorm(78,10) : rnorm(55,12);
    let cloud = label==='Yes'? rnorm(80,12) : rnorm(40,18);
    let pressure = label==='Yes'? rnorm(1003,4.5) : rnorm(1015,5.5);
    let wind = label==='Yes'? rnorm(4.5,1.6) : rnorm(3.0,1.4);
    let temp = tempBySeason(season, label==='Yes');

    temp = clamp(temp + rnorm(0, 0.8), -5, 45);
    humidity = clamp(humidity + rnorm(0, 2), 5, 100);
    cloud = clamp(cloud + rnorm(0, 4), 0, 100);
    pressure = clamp(pressure + rnorm(0, 0.8), 980, 1040);
    wind = clamp(Math.abs(wind + rnorm(0, .4)), 0, 25);

    return { temperature: temp, humidity, pressure, wind, cloud, season, label };
  }

  function generateData(n){
    const arr = [];
    for(let i=0;i<n;i++) arr.push(genRow());
    return arr;
  }

  function kfoldAccuracy(rows, k){
    const shuffled = rows.slice().sort(()=>Math.random()-0.5);
    const foldSize = Math.max(1, Math.floor(rows.length/k));
    const accs = [];
    for(let i=0;i<k;i++){
      const start = i*foldSize;
      const test = shuffled.slice(start, start+foldSize);
      const train = shuffled.slice(0, start).concat(shuffled.slice(start+foldSize));
      const nb = new NaiveBayes({
        numeric: ['temperature','humidity','pressure','wind','cloud'],
        categorical: ['season'],
        classes: ['Yes','No']
      });
      nb.fit(train);
      let correct=0;
      for(const r of test){
        const p = nb.predict(r);
        if(p.label===r.label) correct++;
      }
      accs.push(correct/Math.max(test.length,1));
    }
    const avg = accs.reduce((a,b)=>a+b,0)/accs.length;
    return avg;
  }

  const $ = (id)=>document.getElementById(id);
  function setText(id, txt){ $(id).textContent = txt; }
  function show(id){ $(id).classList.remove('hidden'); }
  function hide(id){ $(id).classList.add('hidden'); }

  function trainAndReport(){
    setText('status','Training model...');
    hide('result');
    const dataset = generateData(1200);
    state.dataset = dataset;
    const nb = new NaiveBayes({
      numeric: ['temperature','humidity','pressure','wind','cloud'],
      categorical: ['season'],
      classes: ['Yes','No']
    });
    nb.fit(dataset);
    state.model = nb;

    const acc = kfoldAccuracy(dataset, 5);
    setText('dataset-size', String(dataset.length));
    setText('cv-acc', (acc*100).toFixed(1) + '%');
    setText('status','Model trained');
    show('metrics');
  }

  function onPredict(e){
    e.preventDefault();
    if(!state.model){ return; }
    const row = {
      temperature: parseFloat($('temperature').value),
      humidity: parseFloat($('humidity').value),
      pressure: parseFloat($('pressure').value),
      wind: parseFloat($('wind').value),
      cloud: parseFloat($('cloud').value),
      season: $('season').value
    };
    const pred = state.model.predict(row);
    setText('pred-class', pred.label==='Yes' ? 'Yes 🌧️' : 'No ☀️');
    setText('prob-yes', pred.probs['Yes'].toFixed(3));
    setText('prob-no', pred.probs['No'].toFixed(3));
    show('result');
  }

  function onRetrain(){
    $('retrain-btn').disabled = true;
    setTimeout(()=>{
      trainAndReport();
      $('retrain-btn').disabled = false;
    }, 50);
  }

  window.addEventListener('DOMContentLoaded', ()=>{
    trainAndReport();
    $('predict-form').addEventListener('submit', onPredict);
    $('retrain-btn').addEventListener('click', onRetrain);
  });
})();
